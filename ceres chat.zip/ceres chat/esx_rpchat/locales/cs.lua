Locales['cs'] = {
  ['ooc_prefix'] = 'OOC | %s',
  ['twt_help'] = 'odeslat tweet',
  ['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
  ['me_help'] = 'osobní akce',
  ['me_prefix'] = 'me | %s',
  ['do_help'] = 'RP informace',
  ['do_prefix'] = 'do | %s',
  ['generic_argument_name'] = 'zpráva',
  ['generic_argument_help'] = 'zpráva',
  ['unknown_command'] = '^3%s^0 není platný příkaz!',
}
